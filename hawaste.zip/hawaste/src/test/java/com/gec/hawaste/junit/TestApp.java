package com.gec.hawaste.junit;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gec.hawaste.entity.AppVersion;
import com.gec.hawaste.entity.Examine;
import com.gec.hawaste.entity.ExamineDo;
import com.gec.hawaste.mapper.AppVersionMapper;
import com.gec.hawaste.service.IAppVersionService;
import com.gec.hawaste.service.IExamineService;
import com.gec.hawaste.utils.PageInfo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;

@SpringBootTest
public class TestApp {

    @Autowired
    private AppVersionMapper appVersionMapper;
    @Autowired
    private IAppVersionService appVersionService;
    @Autowired
    private IExamineService examineService;

    @Test
    public void testQuery1() {
        AppVersion appVersion = appVersionMapper.selectById(3L);
        System.out.println(appVersion);
    }

    @Test
    public void testQuery2() {
        Page<AppVersion> page = new Page<>(1, 3);
        page = appVersionService.page(page);
        for (AppVersion version : page.getRecords()) {
            System.out.println(version);
        }
    }

    @Test
    public void testQueryExamine1() {
        Examine examine = examineService.getById(1);
        System.out.println(examine);
    }

    @Test
    public void testQueryExamine2() {
        HashMap<String, Object> params = new HashMap<>();
        params.put("officeId", "56");
        params.put("type", 1);
        params.put("name", "人员");
        PageInfo<ExamineDo> page = new PageInfo<>(1, 5);
        PageInfo<ExamineDo> pageInfo = (PageInfo<ExamineDo>) examineService.selectByCondition(page, params);
        for (ExamineDo examineDo : pageInfo.getRecords()) {
            System.out.println(examineDo);
        }
    }
}


















