package com.gec.hawaste.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class PageController {

    /**
     * 一级路径页面跳转
     *
     * @param url
     * @return
     */
    @GetMapping("{url}.html")
    public String module1(@PathVariable String url) {
        return "index";
    }

    /**
     * 二级路径页面跳转
     *
     * @param module
     * @param url
     * @return
     */
    @GetMapping("{module}/{url}.html")
    public String module2(@PathVariable String module, @PathVariable String url) {
        return module + "/" + url;
    }

    /**
     * 三级路径页面的跳转
     *
     * @param module
     * @param classify
     * @param url
     * @return
     */
    @GetMapping("{module}/{classify}/{url}.html")
    public String module3(@PathVariable String module, @PathVariable String classify, @PathVariable String url) {
        return module + "/" + classify + "/" + url;
    }
}
