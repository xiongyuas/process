package com.gec.hawaste.service;

import com.gec.hawaste.entity.EnvironmentalCompany;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface IEnvironmentalCompanyService extends IService<EnvironmentalCompany> {

}
