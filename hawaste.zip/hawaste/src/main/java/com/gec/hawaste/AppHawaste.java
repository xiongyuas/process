package com.gec.hawaste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppHawaste {
    public static void main(String[] args) {
        SpringApplication.run(AppHawaste.class, args);
    }
}
