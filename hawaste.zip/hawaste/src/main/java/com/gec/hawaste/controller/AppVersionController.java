package com.gec.hawaste.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gec.hawaste.entity.AppVersion;
import com.gec.hawaste.entity.ResultBean;
import com.gec.hawaste.service.IAppVersionService;
import com.gec.hawaste.utils.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
@RestController
@RequestMapping("/manager/app")
public class AppVersionController {

    @Autowired
    private IAppVersionService appVersionService;

    @GetMapping("/select")
    public ResultBean<Page> select(Integer current, Integer size) {
        PageInfo<AppVersion> page = new PageInfo<>(current, size);
        appVersionService.page(page);
        page.setNavigatePage();
        return ResultBean.ok(page);
    }

    @RequestMapping("/selectOne")
    public ResultBean selectOne(Long id) {
        AppVersion version = appVersionService.getById(id);
        System.out.println(version);
        return ResultBean.ok(version);
    }

    /**
     * 添加与更新的请求接口。有主键就更新，无主键就添加
     *
     * @param version
     * @return
     */
    @RequestMapping("/saveOrUpdate")
    public ResultBean saveOrUpdate(@RequestBody AppVersion version) {
        appVersionService.saveOrUpdate(version);
        return ResultBean.ok();
    }

    @RequestMapping("delete")
    public ResultBean delete(Long id) {
        appVersionService.removeById(id);
        return ResultBean.ok();
    }
}



























