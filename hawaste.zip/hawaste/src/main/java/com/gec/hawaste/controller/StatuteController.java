package com.gec.hawaste.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gec.hawaste.entity.ResultBean;
import com.gec.hawaste.entity.Statute;
import com.gec.hawaste.service.IStatuteService;
import com.gec.hawaste.utils.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
@RestController
@RequestMapping("/manager/statute")
public class StatuteController {

    @Autowired
    private IStatuteService statuteService;

    /**
     * 分页查询
     */
    @RequestMapping("select/{current}/{size}")
    public ResultBean<Page> select(@PathVariable Integer current, @PathVariable Integer size, @RequestParam(required = false) Integer type) {
        PageInfo<Statute> page = (PageInfo<Statute>) statuteService.selectByCondition(new PageInfo<>(current, size), type);
        page.setNavigatePage();
        return ResultBean.ok(page);
    }

    //查询整个statute信息
    @RequestMapping("selectOne")
    public ResultBean selectOne(Long id) {
        return ResultBean.ok(statuteService.getById(id));
    }

    /**
     * 更新或插入 无主键插入数据，有主键更新数据
     */
    @PostMapping("saveOrUpdate")
    public ResultBean saveOrUpdate(@RequestBody Statute statute) {
        statuteService.saveOrUpdate(statute);
        return ResultBean.ok();
    }

    /**
     * 删除数据
     */
    @RequestMapping("delete")
    public ResultBean delete(Long id) {
        statuteService.removeById(id);
        return ResultBean.ok();
    }
}














