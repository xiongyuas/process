package com.gec.hawaste.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.gec.hawaste.entity.Examine;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gec.hawaste.entity.ExamineDo;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface ExamineMapper extends BaseMapper<Examine> {
    //${ew.customSqlSegment}表示动态条件的拼接
    @Select("SELECT " +
            "  ex.*, " +
            "  su.name user_name, " +
            "  so.name office_name " +
            "FROM " +
            "  examine ex,sys_user su,sys_office so  ${ew.customSqlSegment}")
    IPage<ExamineDo> selectByCondition(IPage<ExamineDo> page, Wrapper ew);
}





















