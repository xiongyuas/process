package com.gec.hawaste.service;

import com.gec.hawaste.entity.SysLog;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 日志表 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface ISysLogService extends IService<SysLog> {

}
