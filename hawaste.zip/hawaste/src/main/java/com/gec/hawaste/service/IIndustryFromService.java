package com.gec.hawaste.service;

import com.gec.hawaste.entity.IndustryFrom;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface IIndustryFromService extends IService<IndustryFrom> {

}
