package com.gec.hawaste.service;

import com.gec.hawaste.entity.SysUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface ISysUserService extends IService<SysUser> {

}
