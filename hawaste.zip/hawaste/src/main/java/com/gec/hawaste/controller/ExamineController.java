package com.gec.hawaste.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gec.hawaste.entity.ExamineDo;
import com.gec.hawaste.entity.ResultBean;
import com.gec.hawaste.service.IExamineService;
import com.gec.hawaste.utils.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
@RestController
@RequestMapping("/manager/examine")
public class ExamineController {

    @Autowired
    private IExamineService examineService;

    @GetMapping("/select/{current}/{size}")
    public ResultBean<Page> select(@PathVariable int current, @PathVariable int size, @RequestParam Map<String, Object> parms) {
        PageInfo<ExamineDo> page = (PageInfo<ExamineDo>) examineService.selectByCondition(new PageInfo<>(current, size), parms);
        page.setNavigatePage();
        return ResultBean.ok(page);
    }
}




















