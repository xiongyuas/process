package com.gec.hawaste.service;

import com.gec.hawaste.entity.SysOffice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 机构表 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface ISysOfficeService extends IService<SysOffice> {

}
