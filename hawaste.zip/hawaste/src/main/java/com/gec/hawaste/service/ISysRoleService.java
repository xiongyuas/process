package com.gec.hawaste.service;

import com.gec.hawaste.entity.SysRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface ISysRoleService extends IService<SysRole> {

}
