package com.gec.hawaste.service;

import com.gec.hawaste.entity.SysOfficeWaste;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 机构-危废品 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface ISysOfficeWasteService extends IService<SysOfficeWaste> {

}
