package com.gec.hawaste.service;

import com.gec.hawaste.entity.SysRoleOffice;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色-机构 服务类
 * </p>
 *
 * @author gec
 * @since 2021-12-01
 */
public interface ISysRoleOfficeService extends IService<SysRoleOffice> {

}
