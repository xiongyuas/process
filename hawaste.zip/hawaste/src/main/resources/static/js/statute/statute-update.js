let vm = new Vue({
   el:'.main-content',
   data:{
       statute:{},
       ueditorConfig:{
           UEDITOR_HOME_URL:"/ueditor",
           serverURL: '/ueditor/exec',
           maximumWords: 50000
       }
   },
    methods:{
       doUpdate:function () {
            axios({
                url:'/manager/statute/saveOrUpdate',
                data:this.staute,
                method:'post'
            }).then(respose=>{
                if (respose.data.code!=200){
                    layer.msg(respose.data.msg)
                    return;
                }
                parent.layer.msg(respose.data.msg);
                let index = parent.layer.getFrameIndex(window.name);
                parent.layer.close(index);
            }).catch(error=>{
                layer.msg(error.message);
            })
       }
    },
    created:function () {
        this.statute = parent.layer.obj;
    },
    mounted:function () {
        jeDate({
            dateCell:'#modifydate',
            format:'YYYY-MM-dd',
            zIndex:999999999,
            choosefun: val=>{
                this.statute.pubDate = val;
            }
        });
    },
    components:{
       VueUeditorWrap
    }
});






















