let vm = new Vue({
    el: '.main-content',
    data: {
        pageInfo: {
            current: 1,
            size: 5
        },
        type: '',
        statute: ''
    },
    methods: {
        select: function (pageNum, pageSize) {
            axios({
                url: `/manager/statute/select/${pageNum}/${pageSize}`,
                params: {type: this.type}
            }).then(respose => {
                this.pageInfo = respose.data.data;
            }).catch(error => {
                layer.msg(error.message);
            })
        },
        toUpdate: function (status_id) {
            axios({
                url: '/manager/statute/selectOne',
                params: {id: status_id}
            }).then(respose => {
                if (respose.data.code == 500) {
                    layer.msg(respose.data.msg)
                    return;
                }
                layer.obj = respose.data.data;
                let index = layer.open({
                    type: 2,
                    title: '更新statute',
                    content: '/manager/statute/statute-update.html',
                    area: ['60%', '80%'],
                    end: () => {
                        this.select(this.pageInfo.current, this.pageInfo);
                    }
                });
            })
        },
        doDelete: function (sid) {
            alert(sid);
        }
    },
    created: function () {
        this.select(1, this.pageInfo.size);
    }
});





















