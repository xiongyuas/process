let em = new Vue({
    el: '#main-container',
    data: {
        pageInfo: {
            current: 1,
            size: 5
        },
        app: {},
        active: false
    },
    methods: {
        select: function (pageNum, pageSize) {
            axios({
                url: '/manager/app/select',
                params: {
                    current: pageNum,
                    size: pageSize
                }
            }).then(response => {
                console.log(response.data);
                this.pageInfo = response.data.data;
            }).catch(function (error) {
                console.log(error);
            });
        },
        save: function () {
            axios({
                url: '/manager/app/saveOrUpdate',
                data: this.app,
                method: 'post'
            }).then(response => {
                if (response.data.code == 200) {
                    this.clear();
                    this.select(1, this.pageInfo.size);
                    this.active = false;
                }
                layer.msg(response.data.msg);
            }).catch(error => {
                layer.msg(error.message);
            });
        },
        clear: function () {
            this.app = {}
        },
        changeActive: function () {
            this.active = !this.active;
        },
        toUpdate: function (appid) {
            axios({
                url: '/manager/app/selectOne',
                params: {id: appid}
            }).then(response => {
                if (response.data.code == 500) {
                    layer.msg(response.data.msg)
                    return;
                }
                layer.appVersion = response.data.data;
                console.log(layer);
                let index = layer.open({
                    type: 2,
                    title: '更新app',
                    content: '/manager/app/app-update.html',
                    area: ['60%', '80%'],
                    end: () => {
                        this.select(this.pageInfo.current, this.pageInfo.size);
                    }
                });
            })
        },
        doDelete: function (appid) {
            layer.msg('是否删除?', {
                time: 0,
                btn: ['是', '否'],
                yes: index => {
                    axios({
                        url: '/manager/app/delete',
                        params: {
                            id: appid
                        }
                    }).then(response => {
                        layer.close(index);
                        layer.msg(response.data.msg);
                        if (response.data.code == 200) {
                            this.select(this.pageInfo.current, this.pageInfo.size);
                        }
                    });
                }
            });
        }
    },
    created: function () {
        this.select(this.pageInfo.current, this.pageInfo.size);
    }
});
